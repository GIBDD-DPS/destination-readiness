"""Ось 12 — Labor Action Risk (B2B). См. docs/methodology/12_labor_action_risk.md
Интерпретирующая ось — проходит через trust-tier механизм."""
from app.models.schemas import ScoreResult


async def get_labor_action_risk(destination_id: str, date_from: str, date_to: str) -> ScoreResult:
    # TODO: профсоюзные календари забастовок (préavis de grève) + news monitoring
    strike_frequency, dispute_signal = 50.0, 20.0
    score = strike_frequency * 0.5 + dispute_signal * 0.5
    return ScoreResult(
        axis="labor_action_risk",
        score=round(score, 1),
        label="high" if score > 60 else "medium" if score > 30 else "low",
        description="Вероятность трудовых забастовок транспорта в регионе в выбранный период.",
        reason="Такие забастовки случаются несколько раз в год, активных предупреждений сейчас нет.",
        source="union_calendars+news",
    )
