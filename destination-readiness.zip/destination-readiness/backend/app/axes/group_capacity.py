"""Ось 11 — Group Capacity Feasibility (B2B). См. docs/methodology/11_group_capacity.md

Статус, не числовой балл — OK | CONFLICT | AT_RISK.
"""
from app.models.schemas import ScoreResult


async def get_group_capacity(destination_id: str, group_size: int, month: str) -> ScoreResult:
    # TODO: запрос к venue_bookings по конкретному объекту и дате
    daily_capacity, already_booked = 20, 5
    available = daily_capacity - already_booked

    if group_size > available:
        status, reason = "CONFLICT", f"доступно {available} мест из {group_size} нужных"
    elif available - group_size < daily_capacity * 0.1:
        status, reason = "AT_RISK", "менее 10% запаса — риск при доп. индивидуальных бронированиях"
    else:
        status, reason = "OK", None

    return ScoreResult(
        axis="group_capacity", score=None, label=status,
        description="Может ли объект принять группу заявленного размера в выбранную дату.",
        reason=reason, source="venue_booking_api",
    )
