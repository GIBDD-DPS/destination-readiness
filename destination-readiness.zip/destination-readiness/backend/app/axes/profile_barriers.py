"""Ось 9 — Solo/Family/Mobility Barriers. См. docs/methodology/09_solo_family_mobility.md

Возвращает список ScoreResult (несколько барьеров), не один балл — сравнение
направлений друг с другом здесь менее полезно, чем конкретный чек-лист.
"""
from app.models.schemas import ScoreResult, TripQuery


async def get_profile_barriers(destination_id: str, query: TripQuery) -> list[ScoreResult]:
    results = []
    if query.is_solo:
        results.append(ScoreResult(
            axis="profile_solo",
            score=None, label="medium", is_applicable=True,
            description="Насколько хорошо освещены популярные маршруты в тёмное время суток.",
            reason="Центр освещён хорошо, за его пределами освещение слабее.",
            source="municipal_lighting_data",
        ))
    if query.has_children:
        results.append(ScoreResult(
            axis="profile_family",
            score=None, label="low", is_applicable=True,
            description="Удобство передвижения с коляской по историческому центру.",
            reason="Узкие тротуары и брусчатка заметно затрудняют передвижение.",
            source="accessibility_maps",
        ))
    if query.mobility_flag:
        results.append(ScoreResult(
            axis="profile_mobility",
            score=None, label="low", is_applicable=True,
            description="Доля общественного транспорта, оборудованного для людей с ограниченной мобильностью.",
            reason="Многие станции метро в центре без лифтов.",
            source="transit_operator_data",
        ))
    return results
