"""Ось 10 — Supplier Reliability Risk (B2B). См. docs/methodology/10_supplier_reliability.md

Единственная ось, которая физически не может работать без данных партнёра-оператора.
Возвращает not_applicable, если operator_id не передан или истории недостаточно.
"""
from app.models.schemas import ScoreResult


async def get_supplier_reliability(operator_id: str | None, destination_id: str) -> ScoreResult:
    if operator_id is None:
        return ScoreResult(
            axis="supplier_reliability", score=None, label=None, is_applicable=False,
            description="История срывов и овербукинга по вине партнёров на местах.",
            reason="Нужны исторические данные вашего оператора — операция недоступна без operator_id.",
        )
    # TODO: запрос к axis_supplier_reliability / operator_incident_log
    return ScoreResult(
        axis="supplier_reliability", score=None, label="n/a", is_applicable=False,
        description="История срывов и овербукинга по вине партнёров на местах.",
        reason="Недостаточно накопленной истории по этому оператору для расчёта.",
        source="operator_data",
    )
