"""Ось 7 — Payment & Cash Friction. См. docs/methodology/07_payment_friction.md"""
from app.models.schemas import ScoreResult


async def get_payment_friction(destination_id: str) -> ScoreResult:
    # TODO: Visa/Mastercard агрегированные отчёты + периодический импорт по обменникам
    score = 20.0
    return ScoreResult(
        axis="payment_friction",
        score=score,
        label="low",
        description="Насколько легко расплачиваться картой и снимать наличные без переплат.",
        reason="Большинство точек принимает карты, комиссии банкоматов в пределах нормы.",
        source="visa_mastercard_reports",
    )
