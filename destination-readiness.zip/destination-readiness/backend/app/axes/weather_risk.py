"""
Ось 8 — Weather Risk Window.
См. docs/methodology/08_weather_risk.md

Полностью автоматизируется с первого дня — открытые API погоды (NOAA, Open-Meteo).
"""
from app.models.schemas import ScoreResult


async def get_weather_risk(destination_id: str, date_from: str, date_to: str) -> ScoreResult:
    # TODO: реальный запрос к NOAA / Open-Meteo API по историческим рядам
    extreme_event_probability = 35.0  # % дней с историческим экстремальным событием
    comfort_deviation = 40.0

    score = extreme_event_probability * 0.5 + comfort_deviation * 0.5

    return ScoreResult(
        axis="weather_risk",
        score=round(score, 1),
        label="high" if score > 60 else "medium" if score > 30 else "low",
        description="Вероятность экстремальной погоды и отклонение от комфортной температуры в эти даты.",
        reason="Возможна аномальная жара в отдельные дни периода по историческим данным за 20+ лет.",
        source="noaa_historical",
    )
