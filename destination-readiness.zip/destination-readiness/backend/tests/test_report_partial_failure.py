"""
Ключевой архитектурный тест: отказ одной оси не должен ронять весь отчёт.

Non-Coupling Principle требует, чтобы модули были независимы не только
по коду, но и по отказоустойчивости — если Wait Time упал (например,
booking-API отдал 500), Weather Risk и остальные оси всё равно должны
попасть в ответ.
"""
import asyncio
from unittest.mock import AsyncMock, patch

import pytest

from app.main import build_destination_axes
from app.models.schemas import ScoreResult, TripQuery


@pytest.mark.asyncio
async def test_partial_axis_failure_does_not_break_report():
    query = TripQuery(destination="barcelona", month="2026-08", duration_days=7)

    async def failing_axis(*args, **kwargs):
        raise RuntimeError("booking API timeout")

    with patch("app.main.get_wait_time", new=AsyncMock(side_effect=failing_axis)):
        results = await build_destination_axes(query)

    # Wait Time отсутствует в результате, но остальные 7 осей на месте
    axis_names = {r.axis for r in results}
    assert "wait_time" not in axis_names
    assert len(results) == 7
    assert all(isinstance(r, ScoreResult) for r in results)


@pytest.mark.asyncio
async def test_not_applicable_is_not_zero():
    """not_applicable должен явно отличаться от score=0, а не маскироваться под него."""
    from app.axes.supplier_reliability import get_supplier_reliability

    result = await get_supplier_reliability(operator_id=None, destination_id="venice")

    assert result.is_applicable is False
    assert result.score is None  # НЕ 0.0
    assert "operator_id" in result.reason
