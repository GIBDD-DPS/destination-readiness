# Changelog

## [0.1.0-draft] — unreleased
### Added
- Методология всех 13 осей + Trip Cost & Feasibility блок (docs/methodology/)
- Архитектурный документ и схема БД (docs/architecture.md, backend/app/db/schema.sql)
- Trust Tier механизм для интерпретирующих осей (docs/automation_trust_tiers.md)
- HTML-прототип формы ввода и дашборда с RU/EN автоопределением (prototype/dashboard.html)
- Каркас FastAPI-бэкенда: 13 axis-модулей, композитный /v1/report эндпоинт, тест на устойчивость к частичным отказам
