"""
Trip Cost & Feasibility — персональный блок, НЕ входит в 13 осей.
См. docs/methodology/trip_cost_feasibility.md

Зависит от (origin, destination, month, duration, nationality) — уникален
для конкретного запроса, в отличие от 13 осей направления.
"""
from app.models.schemas import ScoreResult, TripQuery


async def get_visa_info(query: TripQuery) -> ScoreResult | None:
    if not query.nationality:
        return None  # нет данных для расчёта — просто не включаем в отчёт, не not_applicable
    # TODO: запрос к visa_requirements по паре (nationality, destination_country)
    required, cost, processing_days, max_stay_days = True, 90.0, 15, 90

    conflict = query.duration_days > max_stay_days
    reason = (
        f"Требуется, стоимость €{cost}, оформление ~{processing_days} дней."
        if not conflict else
        f"ВНИМАНИЕ: длительность поездки ({query.duration_days} дн.) превышает "
        f"разрешённый срок пребывания ({max_stay_days} дн.)."
    )

    return ScoreResult(
        axis="visa",
        score=None,
        label="required" if required else "not_required",
        description="Нужен ли отдельный визовый документ для въезда с указанным гражданством.",
        reason=reason,
        capped_reason="duration_exceeds_max_stay" if conflict else None,
        source="visa_requirements_table",
    )


async def get_flight_price_deviation(query: TripQuery) -> ScoreResult | None:
    if not query.origin:
        return None
    # TODO: запрос медианы маршрута к price_volatility API (Amadeus/Travelpayouts)
    route_median = 380.0
    if query.known_flight_price:
        deviation = (query.known_flight_price - route_median) / route_median * 100
        reason = f"Ваша цена ${query.known_flight_price:.0f} vs медиана маршрута ${route_median:.0f} ({deviation:+.0f}%)."
    else:
        deviation = None
        reason = f"Оценочная медиана маршрута: ${route_median:.0f} (цена не указана)."

    return ScoreResult(
        axis="flight_price",
        score=round(deviation, 1) if deviation is not None else None,
        label=None,
        description="Насколько цена билета отличается от типичной цены на этом маршруте.",
        reason=reason,
        source="flight_price_api",
    )


async def get_tourist_tax(query: TripQuery) -> ScoreResult:
    # TODO: переиспользует Active Restrictions из axis_regulatory_risk (per_night_fee)
    per_night_fee = 2.50
    total = per_night_fee * query.duration_days

    return ScoreResult(
        axis="tourist_tax",
        score=round(total, 2),
        label=None,
        description="Обязательные городские сборы за проживание, умноженные на число ночей.",
        reason=f"€{per_night_fee} за ночь × {query.duration_days} ночей.",
        source="axis_regulatory_risk.active_restrictions",
    )
