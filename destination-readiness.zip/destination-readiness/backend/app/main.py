"""
FastAPI-приложение.

build_report() — единственный композитный эндпоинт. Он НЕ содержит
собственной логики скоринга — только параллельно вызывает нужное
подмножество независимых axis-модулей и собирает JSON для фронтенда.
Тот же принцип CompositeScorer, что и в исходном ТЗ по Agenomics,
только на уровне HTTP, а не Python-классов.
"""

import asyncio
from datetime import date

from fastapi import FastAPI

from app.axes.currency_lock_risk import get_currency_lock_risk
from app.axes.group_capacity import get_group_capacity
from app.axes.health_safety import get_health_safety
from app.axes.infrastructure_load import get_infrastructure_load
from app.axes.labor_action_risk import get_labor_action_risk
from app.axes.local_sentiment import get_local_sentiment
from app.axes.payment_friction import get_payment_friction
from app.axes.price_volatility import get_price_volatility
from app.axes.profile_barriers import get_profile_barriers
from app.axes.regulatory_risk import get_regulatory_risk
from app.axes.supplier_reliability import get_supplier_reliability
from app.axes.trip_cost import get_flight_price_deviation, get_tourist_tax, get_visa_info
from app.axes.wait_time import get_wait_time
from app.axes.weather_risk import get_weather_risk
from app.models.schemas import ReportResponse, ScoreResult, TravelerMode, TripQuery

app = FastAPI(title="Destination Readiness API")


def _safe_results(raw: list) -> list[ScoreResult]:
    """Отбрасывает исключения из asyncio.gather, оставляя только успешные
    результаты. Отказ одного модуля не должен ронять весь отчёт — только
    свою секцию."""
    return [r for r in raw if isinstance(r, ScoreResult)]


async def build_destination_axes(query: TripQuery) -> list[ScoreResult]:
    tasks = [
        get_infrastructure_load(query.destination, query.month),
        get_price_volatility(query.destination, query.month),
        get_wait_time(query.destination),
        get_regulatory_risk(query.destination),
        get_local_sentiment(query.destination),
        get_health_safety(query.destination, query.month),
        get_payment_friction(query.destination),
        get_weather_risk(query.destination, query.month, query.month),
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return _safe_results(results)


async def build_trip_cost(query: TripQuery) -> list[ScoreResult]:
    if not query.nationality and not query.origin:
        return []
    tasks = [get_visa_info(query), get_flight_price_deviation(query), get_tourist_tax(query)]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return [r for r in results if isinstance(r, ScoreResult)]


async def build_profile_barriers(query: TripQuery) -> list[ScoreResult]:
    if not (query.is_solo or query.has_children or query.mobility_flag):
        return []
    try:
        return await get_profile_barriers(query.destination, query)
    except Exception:
        return []


async def build_b2b_axes(query: TripQuery) -> list[ScoreResult]:
    if query.mode != TravelerMode.B2B:
        return []
    tasks = [
        get_supplier_reliability(query.operator_id, query.destination),
        get_group_capacity(query.destination, query.group_size or 1, query.month),
        get_labor_action_risk(query.destination, query.month, query.month),
    ]
    if query.booking_lag_days:
        tasks.append(get_currency_lock_risk("EUR", "EUR", query.booking_lag_days))
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return _safe_results(results)


async def build_report(query: TripQuery) -> ReportResponse:
    destination_axes, trip_cost, profile_barriers, b2b_axes = await asyncio.gather(
        build_destination_axes(query),
        build_trip_cost(query),
        build_profile_barriers(query),
        build_b2b_axes(query),
    )
    return ReportResponse(
        query=query,
        destination_axes=destination_axes,
        trip_cost=trip_cost,
        profile_barriers=profile_barriers,
        b2b_axes=b2b_axes,
        generated_at=date.today(),
        lang=query.detected_lang,
    )


@app.post("/v1/report", response_model=None)
async def report_endpoint(query: TripQuery) -> ReportResponse:
    return await build_report(query)
