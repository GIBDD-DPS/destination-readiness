"""
Ось 13 — Currency & Pricing Lock Risk (B2B).
См. docs/methodology/13_currency_lock_risk.md

Полностью автоматизируется с первого дня — открытые API курсов валют.
Не даёт рекомендации хеджировать/не хеджировать — только входные данные.
"""
from app.models.schemas import ScoreResult


async def get_currency_lock_risk(sales_currency: str, cost_currency: str, booking_lag_days: int) -> ScoreResult:
    # TODO: реальный запрос к финансовому API за 24 месяца истории пары
    pair_volatility_annualized = 12.0  # %

    exposure = pair_volatility_annualized * (booking_lag_days / 365)

    return ScoreResult(
        axis="currency_lock_risk",
        score=round(exposure, 2),
        label="high" if exposure > 8 else "medium" if exposure > 3 else "low",
        description="Насколько колебания курса могут повлиять на стоимость тура при данном сроке продажи.",
        reason=f"Лаг {booking_lag_days} дней между продажей и поездкой при годовой волатильности пары {pair_volatility_annualized}%.",
        source="fx_api",
    )
